
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Breadcrumb -->
        <?php echo $__env->make('admin.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Breadcrumb -->

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header"><?php echo e($panelTitle); ?></h5>
                    <div class="card-body">
                    <?php echo e(Form::open([
                        'method'=> 'POST',
                        'class' => '',
                        'route' => [$routePrefix.'.'.$editUrl, customEncryptionDecryption($role->id)],
                        'name'  => 'updateRoleForm',
                        'id'    => 'updateRoleForm',
                        'files' => true,
                        'novalidate' => true])); ?>

                        <?php echo method_field('PUT'); ?>

                        <div class="row g-3">
                            <div class="col-md-12">
                                <label class="form-label"><?php echo e(__('custom_admin.label_title')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('name', $role->name ?? null, [
                                                            'id' => 'name',
                                                            'class' => 'form-control',
                                                            'placeholder' => __('custom_admin.placeholder_title'),
                                                            'required' => true ])); ?>

                            </div>
                        </div>
                        <hr class="my-4 mx-n4">
                        <div class="row g-3">
                            <!-- Permission section -->
                            <div class="col-md-12 gap-3">
                                <div class="permission-title form-check background-white">
                                    <div>
                                        <input type="checkbox" class="form-check-input cursor-pointer checkAll mainSelectDeselectAll" id="customCheck2All">
                                        <label class="form-check-label cursor-pointer" for="customCheck2All">
                                            <strong><?php echo app('translator')->get('custom_admin.label_select_deselect_all'); ?></strong>
                                        </label>
                                    </div>
                                </div>

                                <?php if(count($routeCollection) > 0): ?>
								<?php $h = 1; ?>
								<?php $__currentLoopData = $routeCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $mainLabel = $group; ?>
									<div class="col-md-12 individual_section">
										<div class="permission-title">
											<h2><strong><?php echo e(ucwords($mainLabel)); ?></strong></h2>
											<div class="custom-control custom-checkbox">
												<input type="checkbox" class="form-check-input cursor-pointer checkAll select_deselect selectDeselectAll" id="customCheck<?php echo e($h); ?>" data-parentRoute="<?php echo e($group); ?>" id="checkboxSuccess<?php echo e($h); ?>">
												<label class="text-dark cursor-pointer ms-1" for="customCheck<?php echo e($h); ?>">
													<?php echo app('translator')->get('custom_admin.label_select_deselect_all'); ?>
												</label>
											</div>
										</div>
										<div class="permission-content section_class">
											<ul>
                                            <?php $listOrIndex = 1; $individualCheckedCount = 0; ?>
											<?php $__currentLoopData = $groupRow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php
												$groupClass = str_replace(' ','_',$group);

												$labelName = str_replace(['admin.','.','-',$group], ['',' ',' ',''], $row['path']);
												if (strpos(trim($labelName), 'index') !== false) {
													$labelName = str_replace('index','List',$labelName);
												} else if (strpos($labelName, 'transfer fees transfer fees') !== false) {
                                                    $labelName = str_replace('transfer fees transfer fees','transfer fees',$labelName);
                                                } else if (strpos($labelName, 'money transfer') !== false) {
                                                    $labelName = str_replace('money transfer','',$labelName);
                                                }
												
												$subClass = str_replace('.','_',$row['path']);

												$listIndexClass = '';
												if ($listOrIndex == 1) $listIndexClass = $group.'_list_index';

                                                if (in_array($row['role_page_id'], $existingPermission)) {
                                                    $individualCheckedCount++;
                                                }
												?>
												<li>
													<div class="custom-control custom-checkbox">
														<input type="checkbox" name="role_page_ids[]" value="<?php echo e($row['role_page_id']); ?>" <?php if(in_array($row['role_page_id'], $existingPermission)): ?>checked <?php endif; ?> data-page="<?php echo e($group); ?>" data-path="<?php echo e($row['path']); ?>" data-class="<?php echo e($groupClass); ?>" data-listIndex="<?php echo e($listIndexClass); ?>" class="form-check-input checkAll setPermission <?php echo e($groupClass); ?> <?php echo e($subClass); ?> selectDeselectAll" id="customCheck_<?php echo e($h); ?>_<?php echo e($listOrIndex); ?>">
														<label class="text-dark cursor-pointer" for="customCheck_<?php echo e($h); ?>_<?php echo e($listOrIndex); ?>">
															<?php echo e(ucwords($labelName)); ?>

														</label>
													</div>
												</li>
												<?php if(count($groupRow) == $individualCheckedCount): ?>
                                                    <script>
                                                    $(document).ready(function(){
                                                        $('.<?php echo e($groupClass); ?>').parents('div.individual_section').find('input[type=checkbox]:eq(0)').prop('checked', true);
                                                    });
                                                    </script>
                                                <?php
                                                endif;
                                                $listOrIndex++;
                                                ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
										</div>
									</div>
									<?php $h++; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
                            </div>
                            <!-- / Permission section -->

                            <div class="mt-4">
                                <a class="btn rounded-pill btn-secondary btn-buy-now text-white" id="btn-cancel" href="<?php echo e(route($routePrefix.'.'.$listUrl)); ?>"><i class='bx bx-left-arrow-circle'></i> <?php echo e(__('custom_admin.btn_cancel')); ?></a>
                                <button type="submit" class="btn rounded-pill btn-primary float-right" id="btn-updating"><i class='bx bx-save'></i> <?php echo e(__('custom_admin.btn_update')); ?></button>
                            </div>
                        </div>
                    <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make($routePrefix.'.'.$pageRoute.'.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', ['title' => $panelTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/role/edit.blade.php ENDPATH**/ ?>