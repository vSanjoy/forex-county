
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Breadcrumb -->
        <?php echo $__env->make('admin.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Breadcrumb -->

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header"><?php echo e($panelTitle); ?></h5>
                    <div class="card-body">
                    <?php echo e(Form::open([
                        'method'=> 'POST',
                        'class' => '',
                        'route' => [$routePrefix.'.'.$pageRoute.'.transfer-fees.transfer-fees-edit', customEncryptionDecryption($transferFee->id)],
                        'name'  => 'updateTransferFeesForm',
                        'id'    => 'updateTransferFeesForm',
                        'files' => true,
                        'novalidate' => true])); ?>

                        <?php echo method_field('PUT'); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_title')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('title', $transferFee->title ?? null, [
                                                            'id' => 'title',
                                                            'class' => 'form-control',
                                                            'placeholder' => __('custom_admin.placeholder_title'),
                                                            'required' => true,
                                                            ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_fees')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('fees', formatToTwoDecimalPlaces($transferFee->fees) ?? null, [
                                                            'id' => 'fees',
                                                            'class' => 'form-control',
                                                            'placeholder' => __('custom_admin.placeholder_fees'),
                                                            'required' => true
                                                            ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_fee_type')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::select('fee_type', config('global.FEE_TYPE_DROPDOWN'), $transferFee->fee_type ?? 'F', [
                                                                                                    'id' => 'fee_type',
                                                                                                    'class' => 'form-select',
                                                                                                    'placeholder' => __('custom_admin.placeholder_fee_type'),
                                                                                                    'required' => true,
                                                                                                    ])); ?>

                            </div>
                            <div class="col-md-12" id="description-div">
                                <label class="form-label"><?php echo e(__('custom_admin.label_description')); ?></label>
                                <?php echo e(Form::textarea('description', $transferFee->description ?? null, [
                                                                'id' => 'description',
                                                                'class' => 'form-select',
                                                                'placeholder' => __('custom_admin.placeholder_description')
                                                                ])); ?>

                            </div>

                            <div class="col-md-12 mt-4">
                                <a class="btn rounded-pill btn-secondary btn-buy-now text-white" id="btn-cancel" href="<?php echo e(route($routePrefix.'.'.$pageRoute.'.transfer-fees.transfer-fees-list', customEncryptionDecryption($transferFee->currency_id))); ?>"><i class='bx bx-left-arrow-circle'></i> <?php echo e(__('custom_admin.btn_cancel')); ?></a>
                                <button type="submit" class="btn rounded-pill btn-primary float-right" id="btn-updating"><i class='bx bx-save'></i> <?php echo e(__('custom_admin.btn_update')); ?></button>
                            </div>
                        </div>
                    <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', ['title' => $panelTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/currency/transfer_fees_edit.blade.php ENDPATH**/ ?>