
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Breadcrumb -->
        <?php echo $__env->make('admin.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Breadcrumb -->
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header"><?php echo e($panelTitle); ?></h5>
                    <div class="card-body">
                    <?php echo e(Form::open([
                        'method'=> 'POST',
                        'class' => '',
                        'route' => [$routePrefix.'.'.$editUrl, customEncryptionDecryption($bank->id)],
                        'name'  => 'updateBankForm',
                        'id'    => 'updateBankForm',
                        'files' => true,
                        'novalidate' => true])); ?>

                        <?php echo method_field('PUT'); ?>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_country_name')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::select('country_id', $countries, $bank->country_id, [
                                                                                'id' => 'country_id',
                                                                                'class' => 'form-select select2',
                                                                                'placeholder' => __('custom_admin.placeholder_select_country'),
                                                                                'required' => true,
                                                                                ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label
                                    class="form-label"><?php echo e(__('custom_admin.placeholder_bank_name')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('bank_name', $bank->bank_name, [
                                                            'id' => 'bank_name',
                                                            'class' => 'form-control',
                                                            'placeholder' => __('custom_admin.placeholder_bank_name'),
                                                            'required' => true
                                                            ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_bank_code')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('bank_code', $bank->bank_code, [
                                                                    'id' => 'bank_code',
                                                                    'class' => 'form-control',
                                                                    'placeholder' => __('custom_admin.label_bank_code'),
                                                                    'required' => true
                                                                    ])); ?>

                            </div>

                        </div>
                        <hr class="my-4 mx-n4">
                        <div class="row g-3">
                            <div class="col-md-6 d-flex align-items-start align-items-sm-center gap-3">
                                <?php
                                    $image = asset("images/".config('global.NO_IMAGE'));
                                    if ($bank->bank_image != null && file_exists(public_path('images/uploads/'.$pageRoute.'/'.$bank->bank_image))) :
                                        $image = asset("images/uploads/".$pageRoute."/".$bank->bank_image);
                                    endif;
                                ?>

                                <div class="preview_img_div_upload position_relative" style="position: relative;">
                                    <img src="<?php echo e($image); ?>" alt="user-avatar" class="d-block rounded" height="100" width="100" id="uploadedAvatar" />
                                    <img id="upload_preview" class="mt-2" style="display: none;" />
                                </div>

                                <div class="button-wrapper">
                                    <label for="upload" class="btn rounded-pill btn-dark mb-4" tabindex="0">
                                        <span class="d-none d-sm-block"><i class='bx bx-upload'></i> <?php echo e(__('custom_admin.label_upload_image')); ?></span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <?php echo e(Form::file('bank_image', [
																		'id' => 'upload',
																		'class' => 'account-file-input upload-image',
																		'hidden' => true
																		])); ?>

                                    </label>
                                    <p class="text-muted mb-0"><?php echo e(__('custom_admin.message_allowed_file_types', ['fileTypes' => config('global.IMAGE_FILE_TYPES')])); ?> </p>
                                </div>
                            </div>

                            <div class="mt-4">
                                <a class="btn rounded-pill btn-secondary btn-buy-now text-white" id="btn-cancel" href="<?php echo e(route($routePrefix.'.'.$listUrl)); ?>"><i class='bx bx-left-arrow-circle'></i> <?php echo e(__('custom_admin.btn_cancel')); ?></a>
                                <button type="submit" class="btn rounded-pill btn-primary float-right" id="btn-updating"><i class='bx bx-save'></i> <?php echo e(__('custom_admin.btn_update')); ?></button>
                            </div>
                        </div>

                    <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make($routePrefix.'.includes.image_preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', ['title' => $panelTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/bank/edit.blade.php ENDPATH**/ ?>