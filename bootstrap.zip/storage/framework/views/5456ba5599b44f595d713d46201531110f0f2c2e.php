<?php
$cmsRoutes          = ['admin.cms.list','admin.cms.create','admin.cms.edit'];
$countryRoutes      = ['admin.country.list','admin.country.create','admin.country.edit'];
$currencyRoutes     = ['admin.currency.list','admin.currency.create','admin.currency.edit','admin.currency.transfer-fees.transfer-fees-list','admin.currency.transfer-fees.transfer-fees-create','admin.currency.transfer-fees.transfer-fees-edit'];
$bankRoutes         = ['admin.bank.list','admin.bank.create','admin.bank.edit'];
$moneyTransferRoutes= ['admin.money-transfer.list'];
$userRoutes          = ['admin.user.list','admin.user.create'];

// Current page route
// $currentPageRoute = explode('admin.', Route::currentRouteName());
// if (count($currentPageRoute) > 0) :
//     $currentPage = $currentPageRoute[1];
// else :
//     $currentPage = Route::currentRouteName();
// endif;

// dd($currentPage, $currencyRoutes);
$currentPage = Route::currentRouteName();

?>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="<?php echo e(route('admin.account.dashboard')); ?>" class="app-brand-link">
            <span class="app-brand-logo demo">
                <?php echo $__env->make('admin.includes.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </span>
        </a>
        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboard -->
        <li class="menu-item <?php if($currentPage == 'admin.account.dashboard'): ?>active <?php endif; ?>">
            <a href="<?php echo e(route('admin.account.dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics"><?php echo e(__('custom_admin.label_dashboard')); ?></div>
            </a>
        </li>

        <!-- Pages -->
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text"><?php echo e(__('custom_admin.label_modules')); ?></span>
        </li>
        <!-- CMS -->
        <li class="menu-item <?php if(in_array($currentPage, $cmsRoutes)): ?>active open <?php endif; ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class='menu-icon bx bxs-coin-stack'></i>
                <div data-i18n="Cms"><?php echo e(__('custom_admin.label_cms')); ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php if(request()->routeIs('admin.cms.list')): ?> active <?php endif; ?>">
                    <a href="<?php echo e(route('admin.cms.list')); ?>" class="menu-link">
                        <div data-i18n="Without menu"><?php echo e(__('custom_admin.label_list')); ?></div>
                    </a>
                </li>
                <li class="menu-item <?php if(request()->routeIs('admin.cms.create')): ?> active <?php endif; ?>">
                    <a href="<?php echo e(route('admin.cms.create')); ?>" class="menu-link">
                        <div data-i18n="Without navbar"><?php echo e(__('custom_admin.label_create')); ?></div>
                    </a>
                </li>
            </ul>
        </li>
        <!-- / CMS -->
        <!-- Country -->
        <li class="menu-item <?php if(in_array($currentPage, $countryRoutes)): ?>active open <?php endif; ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class='menu-icon bx bx-globe'></i>
                <div data-i18n="Country"><?php echo e(__('custom_admin.label_country')); ?></div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php if(request()->routeIs('admin.country.list')): ?> active <?php endif; ?>">
                    <a href="<?php echo e(route('admin.country.list')); ?>" class="menu-link">
                        <div data-i18n="Without menu"><?php echo e(__('custom_admin.label_list')); ?></div>
                    </a>
                </li>
                <li class="menu-item <?php if(request()->routeIs('admin.country.create')): ?> active <?php endif; ?>">
                    <a href="<?php echo e(route('admin.country.create')); ?>" class="menu-link">
                        <div data-i18n="Without navbar"><?php echo e(__('custom_admin.label_create')); ?></div>
                    </a>
                </li>
            </ul>
        </li>
        <!-- / Country -->
        <!-- Currency & Transfer Fees -->
        
        <!-- / Currency & Transfer Fees -->
        <!-- Bank -->
        
        <!-- / Bank -->
        <!-- Money Transfer -->
        
        <!-- / Money Transfer -->

        <!-- User Transfer -->
        
        <!-- / User Transfer -->

    </ul>
</aside>
<?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/includes/navigation.blade.php ENDPATH**/ ?>