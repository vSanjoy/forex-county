<?php if(strpos(Route::currentRouteName(), 'dashboard') === false): ?>
<h6 class="fw-bold py-1 mb-4">
    <span class="text-muted fw-light">
        <a href="<?php echo e(route($routePrefix.'.account.dashboard')); ?>" class=""><?php echo e(__('custom_admin.label_dashboard')); ?></a> /
    </span>
    <?php if(strpos(Route::currentRouteName(), 'settings') === false && strpos(Route::currentRouteName(), 'change-password') === false && strpos(Route::currentRouteName(), 'profile') === false): ?>
        <?php if(isset($breadcrumb[$pageType]) && count($breadcrumb[$pageType]) > 0): ?>
            <?php $__currentLoopData = $breadcrumb[$pageType]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($pageValue['url'] != ''): ?>
                    <span class="text-muted fw-light">
                        <a href="<?php echo e($pageValue['url']); ?>" class=""><?php echo e($pageValue['label']); ?></a> / 
                    </span>
                <?php else: ?>
                    <?php echo e($pageValue['label']); ?>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php else: ?>
        <?php echo e($pageTitle); ?>

    <?php endif; ?>
</h6>
<?php endif; ?>

<?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/includes/breadcrumb.blade.php ENDPATH**/ ?>