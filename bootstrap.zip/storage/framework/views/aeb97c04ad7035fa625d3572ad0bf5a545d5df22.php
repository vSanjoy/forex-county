

<?php $__env->startSection('content'); ?>
    <!-- Forgot Password -->
    <div class="card">
        <div class="card-body">
            <!-- Logo -->
            <?php echo $__env->make('admin.includes.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /Logo -->
            <h4 class="mb-2"><?php echo app('translator')->get('custom_admin.label_forgot_password'); ?>? 🔒</h4>
            <p class="mb-4"><?php echo app('translator')->get('custom_admin.message_registered_email'); ?></p>

            <?php echo e(Form::open([
                'method' => 'POST',
                'class' => 'mb-3',
                'route' => [$routePrefix . '.' . $as . '.forgot-password'],
                'name' => 'forgotPasswordForm',
                'id' => 'forgotPasswordForm',
                'files' => true,
                'novalidate' => true,
            ])); ?>

            <?php echo method_field('PATCH'); ?>
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo app('translator')->get('custom_admin.label_email'); ?><span class="red_star">*</span></label>
                <?php echo e(Form::text('email', null, [
                    'id' => 'email',
                    'class' => 'form-control',
                    'placeholder' => __('custom_admin.message_enter_email'),
                    'required' => true,
                ])); ?>

            </div>
            <button class="btn rounded-pill btn-primary d-grid w-100" id="btn-processing"><i class='bx bxs-paper-plane'></i> <?php echo app('translator')->get('custom_admin.btn_send_reset_link'); ?></button>
            <?php echo e(Form::close()); ?>

            
            <div class="text-center">
                <a href="<?php echo e(route($routePrefix.'.'.$as.'.login')); ?>" class="d-flex align-items-center justify-content-center">
                    <i class='bx bx-chevron-left'></i>
                    <?php echo app('translator')->get('custom_admin.label_back_to_login'); ?>
                </a>
            </div>
        </div>
    </div>
    <!-- /Forgot Password -->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', ['title' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/auth/forgot_password.blade.php ENDPATH**/ ?>