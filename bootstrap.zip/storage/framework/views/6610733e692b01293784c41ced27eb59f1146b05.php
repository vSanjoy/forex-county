
var notyf = new Notyf({
    duration: 3000,
    ripple: true,
    position: {x:'right',y:'top'},
    dismissible: true,

});<?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/includes/notification.blade.php ENDPATH**/ ?>