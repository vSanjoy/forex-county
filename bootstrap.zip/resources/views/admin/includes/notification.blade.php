{{-- Don't need script tag declare as it is include inside the script tag --}}
var notyf = new Notyf({
    duration: 3000,
    ripple: true,
    position: {x:'right',y:'top'},
    dismissible: true,

});