

<?php $__env->startSection('content'); ?>

    <!-- Error -->
    <div class="container-xxl container-p-y">
        <div class="misc-wrapper">
            <h2 class="mb-2 mx-2"><?php echo app('translator')->get('custom_admin.error_page_not_found'); ?> :(</h2>
            <p class="mb-4 mx-2"><?php echo app('translator')->get('custom_admin.message_page_not_found'); ?></p>
            <a href="<?php echo e(url('/')); ?>" class="btn btn-primary"><?php echo app('translator')->get('custom_admin.btn_back_to_home'); ?></a>
            <div class="mt-3">
                <img src="<?php echo e(asset('images/admin/illustrations/page-misc-error-light.png')); ?>" alt="page-misc-error-light" width="500" class="img-fluid" data-app-dark-img="<?php echo e(asset('images/admin/illustrations/page-misc-error-light.png')); ?>" data-app-light-img="<?php echo e(asset('images/admin/illustrations/page-misc-error-light.png')); ?>" />
            </div>
        </div>
    </div>
    <!-- /Error -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::layout', ['title' => 'Not Found'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/errors/404.blade.php ENDPATH**/ ?>