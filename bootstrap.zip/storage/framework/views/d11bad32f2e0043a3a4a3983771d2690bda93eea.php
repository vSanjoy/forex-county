<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            <?php echo app('translator')->get('custom_admin.message_copyright'); ?> &copy; <?php echo e(date('Y')); ?> <?php echo app('translator')->get('custom_admin.message_reserved'); ?>
        </div>
    </div>
</footer>

<input type="hidden" name="admin_url" id="admin_url" value="<?php echo e(url('/adminpanel')); ?>" />
<input type="hidden" name="admin_image_url" id="admin_image_url" value="<?php echo e(asset('images/admin/')); ?>" />
<?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>