

<?php $__env->startSection('content'); ?>
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Breadcrumb -->
        <?php echo $__env->make($routePrefix.'.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Breadcrumb -->

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header"><?php echo e($panelTitle); ?></h5>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="">Sender</label>
                                <input type="text" class="form-control" value="<?php echo e($moneyTransfer->senderDetails->full_name); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Receiver</label>
                                <input type="text" class="form-control" value="<?php echo e($moneyTransfer->receiverDetails->full_name); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Transfer No.</label>
                                <input type="text" class="form-control" value="<?php echo e($moneyTransfer->transfer_no); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Payment Status</label>
                                <input type="text" class="form-control" value="<?php echo e(paymentStatus($moneyTransfer->payment_status)); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Transfer Status</label>
                                <input type="text" class="form-control" value="<?php echo e($moneyTransfer->forex_country_transfer_status == 'P' ? __('custom_admin.label_paid') : __('custom_admin.label_unpaid')); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Transfer Date</label>
                                <input type="text" class="form-control" value="<?php echo e(changeDateFormat($moneyTransfer->transfer_datetime)); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Status</label>
                                <input type="text" class="form-control" value="<?php echo e(transferStatus($moneyTransfer->status)); ?>">
                            </div>

                        </div>
                        <div class="mt-4">
                            <a class="btn rounded-pill btn-secondary btn-buy-now text-white" id="btn-cancel" href="<?php echo e(route($routePrefix.'.'.$listUrl)); ?>"><i class='bx bx-left-arrow-circle'></i> <?php echo e(__('custom_admin.btn_cancel')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['title' => $panelTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/money-transfer/view.blade.php ENDPATH**/ ?>