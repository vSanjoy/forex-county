

<?php $__env->startSection('content'); ?>
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
		<!-- Breadcrumb -->
		<?php echo $__env->make('admin.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- / Breadcrumb -->

		<div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header"><?php echo e($panelTitle); ?></h5>
						<div class="card-datatable table-responsive">
							<table id="list-table" class="dt-row-grouping table border-top table-striped">
								<thead>
									<tr>
										<th class="zeroColumn table-th-display-none"></th>
										<th class="firstColumn"><?php echo app('translator')->get('custom_admin.label_hash'); ?></th>
										<th><?php echo app('translator')->get('custom_admin.label_image'); ?></th>
										<th><?php echo app('translator')->get('custom_admin.label_country_name'); ?></th>
										<th><?php echo app('translator')->get('custom_admin.label_serial_number'); ?></th>
										<th><?php echo app('translator')->get('custom_admin.label_menu_currency'); ?></th>
										<th class="modifiedColumn"><?php echo app('translator')->get('custom_admin.label_modified'); ?></th>
										<th class="row_status"><?php echo app('translator')->get('custom_admin.label_status'); ?></th>
										<th class="more_actions"><?php echo app('translator')->get('custom_admin.label_action'); ?></th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<?php echo $__env->make($routePrefix.'.'.$pageRoute.'.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', ['title' => $panelTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/currency/list.blade.php ENDPATH**/ ?>