

<?php $__env->startSection('content'); ?>
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
		<!-- Breadcrumb -->
		<?php echo $__env->make('admin.currency.currency-breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- / Breadcrumb -->

		<div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">
						<?php echo e($panelTitle); ?> (<?php echo e($currency->countryDetails->countryname.' - '.$currency->currency); ?>)
						<a class="btn rounded-pill btn-dark btn-buy-now text-white float-right" href="<?php echo e(route($routePrefix.'.'.$pageRoute.'.transfer-fees.transfer-fees-create', customEncryptionDecryption($currency->id))); ?>"><i class='bx bx-plus-circle'></i>&nbsp;<?php echo e(__('custom_admin.btn_create')); ?></a>
					</h5>
						<div class="card-datatable table-responsive">
							<table id="list-table" class="dt-row-grouping table border-top table-striped">
								<thead>
									<tr>
										<th class="zeroColumn table-th-display-none"></th>
										<th class="firstColumn"><?php echo app('translator')->get('custom_admin.label_hash'); ?></th>
										<th><?php echo app('translator')->get('custom_admin.label_title'); ?></th>
										<th><?php echo app('translator')->get('custom_admin.label_fees'); ?></th>
										<th><?php echo app('translator')->get('custom_admin.label_fee_type'); ?></th>
										<th class="modifiedColumn"><?php echo app('translator')->get('custom_admin.label_modified'); ?></th>
										<th class="row_status"><?php echo app('translator')->get('custom_admin.label_status'); ?></th>
										<th class="actions"><?php echo app('translator')->get('custom_admin.label_action'); ?></th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<?php echo $__env->make($routePrefix.'.'.$pageRoute.'.transfer_fees_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', ['title' => $panelTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/currency/transfer_fees_list.blade.php ENDPATH**/ ?>