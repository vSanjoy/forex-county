<h6 class="fw-bold py-1 mb-4">
    <span class="text-muted fw-light">
        <a href="<?php echo e(route($routePrefix.'.account.dashboard')); ?>" class=""><?php echo e(__('custom_admin.label_dashboard')); ?></a> /
    </span>
    <span class="text-muted fw-light">
        <a href="<?php echo e(route($routePrefix.'.'.$listUrl)); ?>" class=""><?php echo e(__('custom_admin.label_currency_list')); ?></a> / 
    </span>
    <?php echo e($pageTitle); ?>    
</h6><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/currency/currency-breadcrumb.blade.php ENDPATH**/ ?>