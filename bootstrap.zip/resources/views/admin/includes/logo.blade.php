<div class="app-brand justify-content-center">
	<a href="index.html" class="app-brand-link gap-2">
		<span class="app-brand-logo demo">
			<img src="{{ asset('images/logo.png') }}" alt="{{ env('APP_NAME') }}" />
		</span>
	</a>
</div>