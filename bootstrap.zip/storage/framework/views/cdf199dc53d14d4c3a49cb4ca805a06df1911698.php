<div class="app-brand justify-content-center">
	<a href="index.html" class="app-brand-link gap-2">
		<span class="app-brand-logo demo">
			<img src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e(env('APP_NAME')); ?>" />
		</span>
	</a>
</div><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/includes/logo.blade.php ENDPATH**/ ?>