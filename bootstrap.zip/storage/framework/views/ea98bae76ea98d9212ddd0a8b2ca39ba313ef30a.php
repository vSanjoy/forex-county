
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Breadcrumb -->
        <?php echo $__env->make('admin.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Breadcrumb -->

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header"><?php echo e($panelTitle); ?></h5>
                    <div class="card-body">
                    <?php echo e(Form::open([
                        'method'=> 'POST',
                        'class' => '',
                        'route' => [$routePrefix.'.'.$editUrl, customEncryptionDecryption($currency->id)],
                        'name'  => 'updateCurrencyForm',
                        'id'    => 'updateCurrencyForm',
                        'files' => true,
                        'novalidate' => true])); ?>

                        <?php echo method_field('PUT'); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_country')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::select('country_id', $countries, $currency->country_id ?? null, [
                                                                                'id' => 'country_id',
                                                                                'class' => 'form-select',
                                                                                'placeholder' => __('custom_admin.placeholder_select_country'),
                                                                                'required' => true,
                                                                                ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_title_currency')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('currency', $currency->currency ?? null, [
                                                            'id' => 'currency',
                                                            'class' => 'form-control',
                                                            'placeholder' => __('custom_admin.placeholder_currency'),
                                                            'required' => true
                                                            ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_short_three_digit_country_code')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('three_digit_currency_code', $currency->three_digit_currency_code ?? null, [
                                                                    'id' => 'three_digit_currency_code',
                                                                    'class' => 'form-control',
                                                                    'placeholder' => __('custom_admin.placeholder_short_three_digit_country_code'),
                                                                    'maxlength' => 3,
                                                                    'required' => true
                                                                    ])); ?>

                            </div>
                            
                            <div class="col-md-12 mt-5">
                                <label class="form-label"><?php echo e(__('custom_admin.message_courrency_manual_exchange_rate')); ?></label>
                                <hr class="mt-0 mb-0">
                            </div>
                        <?php if($otherCurrencies): ?>
                            <?php $__currentLoopData = $otherCurrencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyCurrency => $valCurrency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e($valCurrency->currency. ' ('.$valCurrency->three_digit_currency_code.') - ('.$valCurrency->countryDetails->countryname.')'); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::text('exchange_rate_arr['.$valCurrency->id.']', $exchangeRate[$valCurrency->id] ?? null, [
                                                            'id'=>'exchange_rate'.$valCurrency->id,
                                                            'class' => 'form-control',
                                                            'placeholder' => __('custom_admin.placeholder_exchange_rate'),
                                                            'required' => true
                                                            ])); ?>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </div>
                        <hr class="my-4 mx-n4">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_serial_number')); ?><span class="red_star">*</span></label>
                                <?php echo e(Form::number('serial_number', $currency->serial_number ?? null, [
                                                                        'id' => 'serial_number',
                                                                        'class' => 'form-control',
                                                                        'placeholder' => __('custom_admin.placeholder_serial_number'),
                                                                        'tabindex'=> 2,
                                                                        'min'=> 0,
                                                                        'required' => true,
                                                                        ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_is_this_currency_will_be_avaliable_for_sender')); ?></label>
                                <?php echo e(Form::select('show_in_sender', config('global.NO_YES_DROPDOWN'), $currency->show_in_sender ?? 'Y', [
                                                                                                    'id' => 'show_in_sender',
                                                                                                    'class' => 'form-select'
                                                                                                    ])); ?>

                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('custom_admin.label_is_this_currency_will_be_avaliable_for_receiver')); ?></label>
                                <?php echo e(Form::select('show_in_receiver', config('global.NO_YES_DROPDOWN'), $currency->show_in_receiver ?? 'Y', [
                                                                                                    'id' => 'show_in_receiver',
                                                                                                    'class' => 'form-select'
                                                                                                    ])); ?>

                            </div>

                            <div class="col-md-12 mt-4">
                                <label class="form-label"><?php echo e(__('custom_admin.message_courrency_available_transfer_methods')); ?></label>
                                <hr class="mt-0 mb-0">
                            </div>
                            <?php
                            $moneyTransferMethods = config('global.AVAILABLE_TRANSFER_METHODS');
                            foreach($moneyTransferMethods as $keyMoneyTransferMethods => $valMoneyTransferMethods) :
                                $checkedFlag = false;
                                $text1 = $text2 = null;
                                if (is_array($availableTransferOptions) && array_key_exists($keyMoneyTransferMethods, $availableTransferOptions)) :
                                    $checkedFlag = true;
                                    $text1 = $availableTransferOptions[$keyMoneyTransferMethods]['avaliable_in'];
                                    $text2 = $availableTransferOptions[$keyMoneyTransferMethods]['description'];
                                endif;
                            ?>
                                <div class="col-md-12">
                                    <div class="form-check form-check-dark">
                                        <?php echo Form::checkbox('available_transfer_option_arr['.$keyMoneyTransferMethods.'][id]', $keyMoneyTransferMethods, $checkedFlag, [
                                                                                    'class' => 'form-check-input',
                                                                                    'id'=>'customCheckDark_'.$keyMoneyTransferMethods
                                                                                    ]); ?>

                                        <label class="form-check-label" for="customCheckDark_<?php echo e($keyMoneyTransferMethods); ?>"> <?php echo e($valMoneyTransferMethods); ?> </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <?php echo e(Form::text('available_transfer_option_arr['.$keyMoneyTransferMethods.'][avaliable_in]', $text1, [
                                                                    'id' => 'available_transfer_option_avaliable_in_'.$keyMoneyTransferMethods,
                                                                    'class' => 'form-control',
                                                                    'placeholder' => __('custom_admin.placeholder_the_money_will_be_available_in_text')
                                                                    ])); ?>

                                </div>
                                <div class="col-md-6">
                                    <?php echo e(Form::textarea('available_transfer_option_arr['.$keyMoneyTransferMethods.'][description]', $text2, [
                                                                    'id'=>'available_transfer_option_description_'.$keyMoneyTransferMethods,
                                                                    'class' => 'form-control',
                                                                    'placeholder' => __('custom_admin.placeholder_short_description'),
                                                                    'rows' => 2
                                                                    ])); ?>

                                </div>
                                <div class="col-md-12 mt-3"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-12 d-flex align-items-start align-items-sm-center gap-3">
                                <?php
								$image = asset("images/".config('global.NO_IMAGE'));
								if ($currency->bank_image != null && file_exists(public_path('images/uploads/'.$pageRoute.'/'.$currency->bank_image))) :
                                    $image = asset("images/uploads/".$pageRoute."/".$currency->bank_image);
                                endif;
								?>
                                <div class="preview_img_div_upload position_relative" style="position: relative;">
                                    <img src="<?php echo e($image); ?>" alt="" class="d-block rounded" height="100" width="100" id="uploadedAvatar"/>
                                    <img id="upload_preview" class="mt-2" style="display: none;"/>
                                </div>
                                <div class="button-wrapper">
                                    <label for="upload" class="btn rounded-pill btn-dark mb-4" tabindex="0">
                                        <span class="d-none d-sm-block"><i class='bx bx-upload'></i> <?php echo e(__('custom_admin.label_upload_bank_image')); ?></span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <?php echo e(Form::file('image', [
                                                                'id' => 'upload',
                                                                'class' => 'account-file-input upload-image',
                                                                'hidden' => true
                                                                ])); ?>

                                    </label>
                                    <p class="text-muted mb-0"><?php echo e(__('custom_admin.message_allowed_file_types', ['fileTypes' => config('global.IMAGE_FILE_TYPES')])); ?> </p>
                                </div>
                            </div>

                            <div class="mt-4">
                                <a class="btn rounded-pill btn-secondary btn-buy-now text-white" id="btn-cancel" href="<?php echo e(route($routePrefix.'.'.$listUrl)); ?>"><i class='bx bx-left-arrow-circle'></i> <?php echo e(__('custom_admin.btn_cancel')); ?></a>
                                <button type="submit" class="btn rounded-pill btn-primary float-right" id="btn-updating"><i class='bx bx-save'></i> <?php echo e(__('custom_admin.btn_update')); ?></button>
                            </div>
                        </div>
                    <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make($routePrefix.'.includes.image_preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', ['title' => $panelTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/currency/edit.blade.php ENDPATH**/ ?>