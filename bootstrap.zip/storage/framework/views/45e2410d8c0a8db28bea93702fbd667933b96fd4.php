<script type="text/javascript">
$(document).ready(function() {
	<?php echo $__env->make('admin.includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php if(Route::currentRouteName() == $routePrefix.'.'.$listUrl): ?>
	// Get list page data
	var getListDataUrl = "<?php echo e(route($routePrefix.'.'.$listRequestUrl)); ?>";	
	var dTable = $('#list-table').on('init.dt', function () {$('#dataTableLoading').hide(); $('ul.pagination').addClass('pagination-round pagination-dark');}).DataTable({
			destroy: true,
			autoWidth: false,
	        responsive: false,
			processing: true,
			language: {
				search: "_INPUT_",
				searchPlaceholder: '<?php echo e(trans("custom_admin.btn_search")); ?>',
				emptyTable: '<?php echo e(trans("custom_admin.message_no_records_found")); ?>',
				zeroRecords: '<?php echo e(trans("custom_admin.message_no_records_found")); ?>',
				paginate: {
					first: '<i class="bx bx-chevrons-left"></i>',
					previous: '<i class="bx bx-chevron-left"></i>',
					next: '<i class="bx bx-chevron-right"></i>',
					last: '<i class="bx bx-chevrons-right"></i>',
				}
			},
			serverSide: true,
			ajax: {
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
	        	url: getListDataUrl,
				type: 'POST',
				data: function(data) {},
	        },
	        columns: [			
				{data: 'id', name: 'id'},
	            {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
				{data: 'page_name', name: 'page_name'},
				{data: 'title', name: 'title'},
				// {data: 'created_at', name: 'created_at', orderable: false, searchable: false},
				{data: 'status', name: 'status'},
			<?php if($isAllow || in_array('cms.edit', $allowedRoutes)): ?>
				{data: 'action', name: 'action', orderable: false, searchable: false},
			<?php endif; ?>
	        ],
			columnDefs: [
				{
					targets: [ 0 ],
					visible: false,
					searchable: false,
            	},
			],
	        order: [
				[0, 'desc']
			],
			pageLength: 25,
			lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, '<?php echo e(trans("custom_admin.label_all")); ?>']],
			fnDrawCallback: function(settings) {
				if (settings._iDisplayLength == -1 || settings._iDisplayLength > settings.fnRecordsDisplay()) {
            		$('#list-table_paginate').hide();
        		} else {
            		$('#list-table_paginate').show();
        		}
			},
	});
	
	// Prevent alert box from datatable & console error message
	$.fn.dataTable.ext.errMode = 'none';	
	$('#list-table').on('error.dt', function (e, settings, techNote, message) {
		$('#dataTableLoading').hide();
		notyf.error(message, "<?php echo app('translator')->get('custom_admin.message_error'); ?>");
	});
	
	// Status section
	$(document).on('click', '.status', function() {
		var id 			= $(this).data('id');
		var actionType 	= $(this).data('action-type');
		listActions('<?php echo e($pageRoute); ?>', 'status', id, actionType, dTable);
	});
	
	// Delete section
	$(document).on('click', '.delete', function() {
		var id = $(this).data('id');
		var actionType 	= $(this).data('action-type');
		listActions('<?php echo e($pageRoute); ?>', 'delete', id, actionType, dTable);
	});
	<?php endif; ?>

});
</script><?php /**PATH E:\xampp8.2\htdocs\forex-county\resources\views/admin/cms/scripts.blade.php ENDPATH**/ ?>